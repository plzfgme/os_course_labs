#include "../../include/mem.h"

unsigned long malloc(unsigned long size){
	//本函数需要实现！！！

    //调用实现的dPartition或者是ePartition的alloc
}

unsigned long free(unsigned long start){
	//本函数需要实现！！！

    //调用实现的dPartition或者是ePartition的free
}