﻿本实验
1）内存检测，扣除OS占用内存，计算出动态内存范围
2）提供动态分区和等大小固定分区，两种管理机制
3）使用动态分区机制管理动态内存，并封装出kmalloc/kfree和malloc/free两套接口
4）shell可以动态增加命令
5）自测


主要功能模块：
内存检测
动态分区
等大小固定分区
kmalloc/free
malloc/free
shell动态增加命令
测试用例



