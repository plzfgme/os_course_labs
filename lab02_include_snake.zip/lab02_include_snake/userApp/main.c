/* 
 * 请确保以下的代码可以原封不动的成功编译和执行
 * 助教测试时会替换相应的参数
 * 不需要修改
 * （全部划掉）
 */

/*
 * snake game!（玩蛇呢你）
 * based on lab2
**/

#include "io.h"
#include "myPrintk.h"
#include "uart.h"
#include "vga.h"

unsigned char input()
{ //always return the last read character immediately
    return inb(uart_base);
}

#define log(x) uart_put_chars(x)

void set_value(char color, char c, int _x, int _y)
{
    *(short*)(VGA_BASE + (_y * VGA_COL + _x) * 2) = ((color & 0xff) << 8) | (c & 0xff);
}
short get_value(int _x, int _y)
{
    return *(short*)(VGA_BASE + (_y * VGA_COL + _x) * 2);
}

#define COLOR_BORDER 0x77
#define COLOR_BACK 0x00 //background
#define COLOR_HEAD 0x55
#define COLOR_SNAKE 0x22
#define COLOR_SCORE 0x66
#define COLOR_COLLIDE 0x44

#define REGION_LEFT 1
#define REGION_TOP 1
#define REGION_WIDTH 20
#define REGION_HEIGHT 20
#define REGION_X_RATIO 2 //indicates the width of a snake game block is 2 times as the width of a vga block.
#define REGION_Y_RATIO 1

#define get_color(_x, _y) ((get_value(REGION_LEFT + _x * REGION_X_RATIO, REGION_TOP + _y * REGION_Y_RATIO) >> 8) & 0xff)

#define DELAY_MAX 0x10000 //(time unit/move) \
    //speed: (move/time unit)                \
    //not so exactly

#define left(x) ((x + REGION_WIDTH - 1) % REGION_WIDTH)
#define right(x) ((x + 1) % REGION_WIDTH)
#define up(x) ((x + REGION_HEIGHT - 1) % REGION_HEIGHT)
#define down(x) ((x + 1) % REGION_HEIGHT)

#define is_left(x) (x == 'a' || x == 'A')
#define is_right(x) (x == 'd' || x == 'D')
#define is_up(x) (x == 'w' || x == 'W')
#define is_down(x) (x == 's' || x == 'S')
#define is_direction(x) (is_left(x) || is_right(x) || is_up(x) || is_down(x))

#define BUFFER_SIZE 400
#define MAX_BUFFER_USAGE (BUFFER_SIZE * 7 >> 3)

#define FULL_DRAW 1
#define UPDATE_DRAW 0

#define __ROR__(x, n) ((x >> n) | (x << (32 - n)))
//random number generator
//these constants were chosen casually
unsigned int _seed = 0xcba98765u;
unsigned int rand()
{
    _seed = __ROR__((0xe771cbb3u * _seed + 0x916fc3dbu) ^ 0xca965369u, 11);
    return _seed;
}
void srand(unsigned int seed)
{
    _seed = seed;
    rand();
}

void draw_block(char color, int _x, int _y)
{
    for (int i = 0; i < REGION_X_RATIO; i++)
        for (int j = 0; j < REGION_Y_RATIO; j++)
            set_value(color, ' ', REGION_LEFT + REGION_X_RATIO * _x + i, REGION_TOP + REGION_Y_RATIO * _y + j);
}

void clear()
{
    clear_screen();

    for (int i = REGION_LEFT - 1; i < REGION_LEFT + REGION_WIDTH * REGION_X_RATIO + 1; i++) {
        set_value(COLOR_BORDER, ' ', i, REGION_TOP - 1);
        set_value(COLOR_BORDER, ' ', i, REGION_TOP + REGION_HEIGHT * REGION_Y_RATIO);
    }
    for (int i = REGION_TOP - 1; i < REGION_TOP + REGION_HEIGHT * REGION_Y_RATIO + 1; i++) {
        set_value(COLOR_BORDER, ' ', REGION_LEFT - 1, i);
        set_value(COLOR_BORDER, ' ', REGION_LEFT + REGION_WIDTH * REGION_X_RATIO, i);
    }
    for (int i = REGION_LEFT; i < REGION_LEFT + REGION_WIDTH * REGION_X_RATIO; i++) {
        for (int j = REGION_TOP; j < REGION_TOP + REGION_HEIGHT * REGION_Y_RATIO; j++) {
            set_value(COLOR_BACK, ' ', i, j);
        }
    }
}

void draw_snake(int length, char* directions, int head_x, int head_y, char full_draw)
{
    draw_block(COLOR_HEAD, head_x, head_y);

    for (int i = 0; i < length; i++) {
        if is_up (directions[-i - 1])
            head_y = down(head_y);
        else if is_down (directions[-i - 1])
            head_y = up(head_y);
        else if is_left (directions[-i - 1])
            head_x = right(head_x);
        else if is_right (directions[-i - 1])
            head_x = left(head_x);
        else if (i == length - 1) {
            //Normal case.
            return;
        } else {
            myPrintf(0x47, "Unknown direction character: %c.\nHalt with error.\n", directions[i]);
            while (1)
                ; //halt
        }

        if (i == 0 || full_draw)
            draw_block(COLOR_SNAKE, head_x, head_y);
    }
    draw_block(COLOR_BACK, head_x, head_y);
}

void draw_collision(int _x, int _y)
{
    draw_block(COLOR_COLLIDE, _x, _y);
}

void draw_score(int _x, int _y)
{
    draw_block(COLOR_SCORE, _x, _y);
}

void draw_head(int head_x, int head_y)
{
    draw_block(COLOR_HEAD, head_x, head_y);
}

void generate_score()
{
    int _x, _y;
    do {
        _x = rand() % REGION_WIDTH;
        _y = rand() % REGION_HEIGHT;
    } while (get_color(_x, _y) != COLOR_BACK);
    /**/
    draw_score(_x, _y);
}

void init_score()
{
    draw_score(REGION_WIDTH - 1, REGION_HEIGHT - 1);
}

char is_tail(int length, char* directions, int head_x, int head_y)
{
    int _x = head_x, _y = head_y;
    for (int i = 0; i < length; i++) {
        if is_up (directions[-i - 1])
            head_y = down(head_y);
        else if is_down (directions[-i - 1])
            head_y = up(head_y);
        else if is_left (directions[-i - 1])
            head_x = right(head_x);
        else if is_right (directions[-i - 1])
            head_x = left(head_x);
        else if (i == length - 1) {
            //Normal case.
            return 0;
        } else {
            myPrintf(0x47, "Unknown direction character: %c.\nHalt with error.\n", directions[i]);
            while (1)
                ; //halt
        }
    }
    return _x == head_x && _y == head_y;
}

//Code comments itself.
//only 'buffer' and 'directions' may be ambiguous.
void myMain(void)
{
    char buffer[BUFFER_SIZE] = "ssddd";
    int length = 5;
    char* directions = buffer + length;
    int head_x = 5, head_y = 10;

    clear();
    draw_snake(length, directions, head_x, head_y, FULL_DRAW);
    init_score();

    char direction = 0, last_direction = 0;
    int delay = 0;
    log("Snake Game!\n");
    log("Press w/s/a/d in serial to start game and move.\n");

    while (!last_direction) {
        direction = input();
        if is_direction (direction)
            last_direction = 'd';

        rand();
        for (int i = 0; i < 0x200; i++)
            ;
    }
    log("Game start!\n");

    while (1) {
        delay++;
        direction = input();

        if (delay < DELAY_MAX)
            continue;
        else
            delay = 0;

        srand(__ROR__(direction * rand(), 7) ^ rand());

        if (is_up(direction) && !is_down(last_direction)) {
            head_y = up(head_y);
            last_direction = direction;
        } else if (is_down(direction) && !is_up(last_direction)) {
            head_y = down(head_y);
            last_direction = direction;
        } else if (is_left(direction) && !is_right(last_direction)) {
            head_x = left(head_x);
            last_direction = direction;
        } else if (is_right(direction) && !is_left(last_direction)) {
            head_x = right(head_x);
            last_direction = direction;
        } else if is_up (last_direction)
            head_y = up(head_y);
        else if is_down (last_direction)
            head_y = down(head_y);
        else if is_left (last_direction)
            head_x = left(head_x);
        else if is_right (last_direction)
            head_x = right(head_x);

        *(directions++) = last_direction;
        //clear();
        switch (get_color(head_x, head_y)) {
        case COLOR_SNAKE:
            if (!is_tail(length, directions, head_x, head_y)) {
                draw_collision(head_x, head_y);
                log("You lose!\n");
                return;
            } else {
                draw_snake(length, directions, head_x, head_y, UPDATE_DRAW);
                draw_head(head_x, head_y);
                break;
            }
        case COLOR_SCORE:
            length++;
            draw_snake(length, directions, head_x, head_y, UPDATE_DRAW);
            generate_score();
            break;
        case COLOR_BACK:
            draw_snake(length, directions, head_x, head_y, UPDATE_DRAW);
            break;
        default:
            myPrintf(0x47, "Unknown block found: (%d, %d) with color %2x\nHalt with error.\n", head_x, head_y, get_color(head_x, head_y));
            while (1)
                ;
        }

        if (directions - buffer >= MAX_BUFFER_USAGE) {
            for (int i = 0; i < length; i++) {
                buffer[i] = directions[i - length];
            }
            directions = buffer + length;
        }
    }
    /**/
}
